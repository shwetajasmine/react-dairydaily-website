CREATE TABLE `r_shopping`.`users` 
(`id` int NOT NULL,
`pname` varchar(50),
`company` varchar(60),
`qty` int(10),
`created_at` timestamp NOT NULL,
`updated_at`  timestamp  NOT NULL DEFAULT CURRENT_TIMESTAMP 
);
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
