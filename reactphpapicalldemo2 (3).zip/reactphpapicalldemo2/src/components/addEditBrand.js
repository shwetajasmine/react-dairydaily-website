import React, { useState, useEffect } from "react";
import { doc, updateDoc, getDoc } from "firebase/firestore";
import { db } from "../firebase";

const AddOrEditBrand = (props) => {
  const initialFieldValues = {
    Brandname: "",
    Description: "",
    Brandyr: "",
    Brandcat: "",
    Brandtype: "",
  };

  var [values, setValues] = useState(initialFieldValues);
  var [id, setId] = useState("");

  const handleInputChange = (e) => {
    var { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    props.addOrEdit(values);
  };
  const getData = async () => {
    const taskDocRef = doc(db, "swetha", props.currentId);
    const docSnap = await getDoc(taskDocRef);
    console.log(docSnap.data(), ";docSnap");
    setValues(docSnap.data().obj);
  };

  if (props.currentId !== id) {
    setId(props.currentId);
    getData();
  }

  return (
    <form autoComplete="off" onSubmit={handleFormSubmit}>
      <div className="col-12 col-md-12">
        <div className="card">
          <div className="card-header">
            <input
              value={
                props.currentId === ""
                  ? "Add Brand Info"
                  : "Update Brand Info"
              }
            />
          </div>
          <div className="card-body">
            <div className="center-form">
              <div className="row">
                <div className="col-12 col-md-6">
                  <div className="form-group">
                    <label className="col-form-label">
                      Brand Name<span className="mandatoryFieldColor">*</span>
                    </label>
                    <input
                      value={values.Brandname}
                      onChange={handleInputChange}
                      type="text"
                      className="form-control"
                      name="Brandname"
                    />
                  </div>
                </div>
                <div className="col-12 col-md-6">
                  <div className="form-group">
                    <label className="col-form-label">
                      Description<span className="mandatoryFieldColor">*</span>
                    </label>
                    <input
                      value={values.Description}
                      onChange={handleInputChange}
                      type="text"
                      className="form-control"
                      name="Description"
                    />
                  </div>
                </div>
                <div className="col-12 col-md-6">
                  <div className="form-group">
                    <label className="col-form-label">
                      Brandyr<span className="mandatoryFieldColor">*</span>
                    </label>
                    <input
                      value={values.Brandyr}
                      onChange={handleInputChange}
                      type="text"
                      className="form-control"
                      name="Brandyr"
                    />
                  </div>
                </div>

                <div className="col-12 col-md-6">
                  <div className="form-group">
                    <label className="col-form-label">
                      Brandcat<span className="mandatoryFieldColor">*</span>
                    </label>
                    <br></br>
                    <input
                      value="MKPDT"
                      onChange={handleInputChange}
                      type="radio"
      
                      name="Brandcat"
                    />
                    MKPDT
                    <t></t>
                        <input
                      value="CHPDT"
                      onChange={handleInputChange}
                      type="radio"
                      
                      name="Brandcat"
                    />
                    CHPDT
                  </div>
                </div>
   
                <div className="col-12 col-md-6">
                  <div className="form-group">
                    <label className="col-form-label">
                      Brandtype<span className="mandatoryFieldColor">*</span>
                    </label>
                    <select  className="form-control" name="Brandtype"  onChange={handleInputChange}>
                     <option  value ="milkproducts">milkproducts</option>
                     <option  value ="cashewtoffee">cashewtoffee</option>
                     <option  value ="chocolate">chocolate</option>
                     <option  value ="others">others</option>
                    </select>
                  </div>
                </div>

                <div className="col-12 col-md-12">
                  <div className="btn-group mb-3 mt-2 cmn-btn-grp">
                    <input
                      type="submit"
                      value={props.currentId === "" ? "Save" : "Update"}
                      className="btn btn-success btn-block"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};

export default AddOrEditBrand;
