import { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

export default function ListCategory() {
    const navigate = useNavigate();

    const [inputs, setInputs] = useState([]);

    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({...values, [name]: value}));
    }
    const handleSubmit = (event) => {
        event.preventDefault();

        axios.post('http://localhost/api3/category/save', inputs).then(function(response){
            console.log(response.data);
            navigate('/category ');
        });
        
    }
    return (
<>
        <nav>
          <ul>
          <li onClick={() => navigate("../product/list", {replace : true})}>
              <Link >List Products</Link>
            </li>
            <li onClick={() => navigate("../product/create", {replace : true})}>
              <Link >Create Product</Link>
            </li>
            <li onClick={() => navigate("../user/create", {replace : true})}>
              <Link >Create User</Link>
            </li>
            <li onClick={() => navigate("../user/", {replace : true})}>
             <Link>List User</Link>
            </li>   
            <li onClick={() => navigate("../brand/create", {replace : true})}>
              <Link>Create Brand</Link>
            </li>
            <li onClick={() => navigate("../brand/", {replace : true})}>
             <Link>List Brand</Link>
            </li>          
            <li onClick={() => navigate("../category/create", {replace : true})}>
              <Link>Create Category</Link>
            </li>
            <li onClick={() => navigate("../category/", {replace : true})}>
             <Link>List Category</Link>
            </li>   
            <li onClick={() => navigate("../order/create", {replace : true})}>
              <a>Create Order</a>
            </li>
            <li onClick={() => navigate("../order/", {replace : true})}>
             <a>List Order</a>
            </li>                                                     
          </ul>
        </nav>
        <div>
            <h1>Create category</h1>
            <form onSubmit={handleSubmit}>
                <table cellSpacing="10">
                    <tbody>
                        <tr>
                            <th>
                                <label>CategoryName: </label>
                            </th>
                            <td>
                                <input type="text" name="cname" onChange={handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label>Categorycode: </label>
                            </th>
                            <td> 
                                <input type="text" name="catcode" onChange={handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <td colSpan="2" align ="right">
                                <button>Save</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>
</>
    )
}
