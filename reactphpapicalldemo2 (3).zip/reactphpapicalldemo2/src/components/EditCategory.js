import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

export default function ListCategory() {
    const navigate = useNavigate();

    const [inputs, setInputs] = useState([]);

    const {id} = useParams();

    useEffect(() => {
        getCategory();
    },[]);

    function getCategory() {
        axios.get(`http://localhost/api3/categorys/${id}`).then(function(response) {
            console.log(response.data);
            setInputs(response.data);
        });
    }

    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({...values, [name]: value}));
    }
    const handleSubmit = (event) => {
        event.preventDefault();

        axios.put(`http://localhost/api3/category/${id}/edit`, inputs).then(function(response){
            console.log(response.data);
            navigate('/category/');
        });
        
    }
    return (
        <div>
            <h1>Edit category</h1>
            <form onSubmit={handleSubmit}>
                <table cellSpacing="10">
                    <tbody>
                        <tr>
                            <th>
                                <label>CategoryName: </label>
                            </th>
                            <td>
                                <input value={inputs.cname} type="text" name="cname" onChange={handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label>Categorycode: </label>
                            </th>
                            <td> 
                                <input value={inputs.catcode} type="text" name="catcode" onChange={handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <td colSpan="2" align ="right">
                                <button>Save</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>
    )
}
