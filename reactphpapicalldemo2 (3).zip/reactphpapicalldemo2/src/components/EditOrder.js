import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

export default function ListOrder() {
    const navigate = useNavigate();

    const [inputs, setInputs] = useState([]);

    const {id} = useParams();

    useEffect(() => {
        getOrder();
    }, []);

    function getOrder() {
        axios.get(`http://localhost/api4/orders/${id}`).then(function(response) {
            console.log(response.data);
            setInputs(response.data);
        });
    }

    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({...values, [name]: value}));
    }
    const handleSubmit = (event) => {
        event.preventDefault();
        axios.put(`http://localhost/api4/orders/${id}/edit`, inputs).then(function(response){
            console.log(response.data);
            navigate('/order');
        });
        
    }
    return (
        <div>
            <h1>Edit Order</h1>
            <form onSubmit={handleSubmit}>
                <table cellSpacing="10">
                    <tbody>
                        <tr>
                            <th>
                                <label>Productid: </label>
                            </th>
                            <td>
                                <input value={inputs.pid} type="text" name="pid" onChange={handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label>Quantity: </label>
                            </th>
                            <td> 
                                <input value={inputs.qty} type="text" name="qty" onChange={handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label>Invoiceno: </label>
                            </th>
                            <td>
                                <input value={inputs.invoiceno} type="text" name="invoiceno" onChange={handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label>Cusname: </label>
                            </th>
                            <td> 
                                <input value={inputs.cusname}  type="text" name="cusname" onChange={handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label>Cusphno: </label>
                            </th>
                            <td> 
                                <input value={inputs.cphno}  type="text" name="cphno" onChange={handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label>Paymentmode: </label>
                            </th>
                            <td> 
                                <input value={inputs.paymentmode} type="text" name="paymentmode" onChange={handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label>Amount: </label>
                            </th>
                            <td> 
                                <input value={inputs.amount} type="text" name="amount" onChange={handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <td colSpan="2" align ="right">
                                <button>Save</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>
    )
}
