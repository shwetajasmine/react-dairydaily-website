import axios from "axios"
import { useEffect, useState } from "react";
import { Link,useNavigate } from "react-router-dom";

export default function ListBrand() {
const navigate = useNavigate();
    const [brands, setBrands] = useState([]);
    useEffect(() => {
        getBrand();
    }, []);

    function getBrand() {
        axios.get('http://localhost/api2/brands/').then(function(response) {
            console.log(response.data);
            setBrands(response.data);
        });
    }

    const deleteBrand = (id) => {
        axios.delete(`http://localhost/api2/brand/${id}/delete`).then(function(response){
            console.log(response.data);
            getBrand();
        });
    }
    return (
<>
        <nav>
          <ul>
          <li onClick={() => navigate("product/ListProduct", {replace : true})}>
              <Link >List Products</Link>
            </li>
            <li onClick={() => navigate("../product/create", {replace : true})}>
              <Link >Create Product</Link>
            </li>
            <li onClick={() => navigate("../user/create", {replace : true})}>
              <Link >Create User</Link>
            </li>
            <li onClick={() => navigate("../user/", {replace : true})}>
              <Link>List User</Link>
            </li>      
            <li onClick={() => navigate("../brand/create", {replace : true})}>
              <Link >Create Brand</Link>
            </li>
            <li onClick={() => navigate("../brand/", {replace : true})}>
              <Link>List Brand</Link>
            </li>    
            <li onClick={() => navigate("../category/create", {replace : true})}>
              <Link >Create Category</Link>
            </li>
            <li onClick={() => navigate("../category/", {replace : true})}>
              <Link>List Category</Link>
            </li>  
            <li onClick={() => navigate("../order/create", {replace : true})}>
              <Link >Create Order</Link>
            </li>
            <li onClick={() => navigate("../order/", {replace : true})}>
              <Link>List Order</Link>
            </li>           
            <li onClick={() => navigate("../brandInfo/", {replace : true})}>
              <Link>BrandInfo</Link>
            </li>           
          </ul>
        </nav>
        <div>
            <h1>List Brand</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>BName</th>
                        <th>Description</th>
                        <th>Brandyear</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {brands.map((brand, key) =>
                        <tr key={key}>
                            <td>{brand.id}</td>
                            <td>{brand.bname}</td>
                            <td>{brand.description}</td>
                            <td>{brand.brandyear}</td>
                            <td>
                                <Link to={`/brand/${brand.id}/edit`} style={{marginRight: "10px"}}>Edit</Link>
                                <button onClick={() => deleteBrand(brand.id)}>Delete</button>
                            </td>
                        </tr>
                    )}
                    
                </tbody>
            </table>
        </div>
        </>
    )
}
