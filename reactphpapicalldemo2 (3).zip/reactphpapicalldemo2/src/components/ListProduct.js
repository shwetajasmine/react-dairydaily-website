import axios from "axios"
import { useEffect, useState } from "react";
import { Link,useNavigate } from "react-router-dom";

export default function ListProduct() {
const navigate = useNavigate();
    const [products, setProducts] = useState([]);
    useEffect(() => {
        getProduct();
    }, []);

    function getProduct() {
        axios.get('http://localhost/api1/products/').then(function(response) {
            console.log(response.data);
            setProducts(response.data);
        });
    }

    const deleteProduct = (id) => {
        axios.delete(`http://localhost/api1/product/${id}/delete`).then(function(response){
            console.log(response.data);
            getProduct();
        });
    }
    return (
<>
        <nav>
          <ul>
          <li onClick={() => navigate("product/ListProduct", {replace : true})}>
              <Link >List Products</Link>
            </li>
            <li onClick={() => navigate("../product/create", {replace : true})}>
              <Link >Create Product</Link>
            </li>
            <li onClick={() => navigate("../user/create", {replace : true})}>
              <Link >Create User</Link>
            </li>
            <li onClick={() => navigate("../user/", {replace : true})}>
              <Link>List User</Link>
            </li> 
            <li onClick={() => navigate("../brand/create", {replace : true})}>
              <Link >Create Brand</Link>
            </li>
            <li onClick={() => navigate("../brand/", {replace : true})}>
              <Link>List Brand</Link>
            </li>  
            <li onClick={() => navigate("../category/create", {replace : true})}>
              <Link >Create Category</Link>
            </li>
            <li onClick={() => navigate("../category/", {replace : true})}>
              <Link>List Category</Link>
            </li> 
            <li onClick={() => navigate("../order/create", {replace : true})}>
              <Link >Create Order</Link>
            </li>
            <li onClick={() => navigate("../order/", {replace : true})}>
              <Link>List Order</Link>
            </li>   
            <li onClick={() => navigate("../brandInfo/", {replace : true})}>
            <Link>BrandInfo</Link>
            </li>                
          </ul>
        </nav>
        <div>
            <h1>List Product</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>PName</th>
                        <th>Company</th>
                        <th>Quantity</th>
                        <th>b_id</th>
                        <th>c_id</th>
                        <th>price</th>

                       

                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {products.map((product, key) =>
                        <tr key={key}>
                            <td>{product.id}</td>
                            <td>{product.pname}</td>
                            <td>{product.company}</td>
                            <td>{product.qty}</td>
                            <td>{product.b_id}</td>
                            <td>{product.c_id}</td>
                            <td>{product.price}</td>
                            <td>
                                <Link to={`product/${product.id}/edit`} style={{marginRight: "10px"}}>Edit</Link>
                                <button onClick={() => deleteProduct(product.id)}>Delete</button>
                            </td>
                        </tr>
                    )}
                    
                </tbody>
            </table>
        </div>
        </>
    )
}
