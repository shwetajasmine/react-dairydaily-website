import axios from "axios"
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function ListCategory() {
 const navigate = useNavigate();
    const [categorys, setCategorys] = useState([]);
    useEffect(() => {
        getCategorys();
    }, []);

    function getCategorys() {
        axios.get('http://localhost/api3/category/').then(function(response) {
            console.log(response.data);
            setCategorys(response.data);
        });
    }

    const deleteCategory = (id) => {
        axios.delete(`http://localhost/api3/category/${id}/delete`).then(function(response){
            console.log(response.data);
            getCategorys();
        });
    }
    return (
<>
        <nav>
          <ul>
          <li onClick={() => navigate("user/ListProduct", {replace : true})}>
              <Link >List Products</Link>
            </li>
            <li onClick={() => navigate("../product/create", {replace : true})}>
              <Link >Create Product</Link>
            </li>
            <li onClick={() => navigate("../user/create", {replace : true})}>
              <Link >Create User</Link>
            </li>
            <li onClick={() => navigate("../user/", {replace : true})}>
             <Link>List User</Link>
            </li>    
            <li onClick={() => navigate("../brand/create", {replace : true})}>
              <Link >Create Brand</Link>
            </li>
            <li onClick={() => navigate("../brand/", {replace : true})}>
              <Link>List Brand</Link>
            </li>   
            <li onClick={() => navigate("../category/create", {replace : true})}>
              <Link >Create Category</Link>
            </li>
            <li onClick={() => navigate("../category/", {replace : true})}>
              <Link>List Category</Link>
            </li>  
            <li onClick={() => navigate("../order/create", {replace : true})}>
              <Link >Create Order</Link>
            </li>
            <li onClick={() => navigate("../order/", {replace : true})}>
              <Link>List Order</Link>
            </li>   
            <li onClick={() => navigate("../brandInfo/", {replace : true})}>
              <Link>BrandInfo</Link>
            </li>                              
          </ul>
        </nav>
        <div>
            <h1>List Category</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>CategoryName</th>
                        <th>Categorycode</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {categorys.map((category, key) =>
                        <tr key={key}>
                            <td>{category.id}</td>
                            <td>{category.cname}</td>
                            <td>{category.catcode}</td>
                            <td>
                            <Link to={`${category.id}/edit`} style={{marginRight: "10px"}}>Edit</Link>
                                <button onClick={() => deleteCategory(category.id)}>Delete</button>
                            </td>
                        </tr>
                    )}
                    
                </tbody>
            </table>
        </div>
</>
    )
}
