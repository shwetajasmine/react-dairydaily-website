import axios from "axios"
import { useEffect, useState } from "react";
import { Link,useNavigate } from "react-router-dom";

export default function ListOrder() {
const navigate = useNavigate();
    const [orders, setOrders] = useState([]);
    useEffect(() => {
        getOrder();
    }, []);

    function getOrder() {
        axios.get('http://localhost/api4/orders/').then(function(response) {
            console.log(response.data);
            setOrders(response.data);
        });
    }

    const deleteOrder = (id) => {
        axios.delete(`http://localhost/api4/order/${id}/delete`).then(function(response){
            console.log(response.data);
            getOrder();
        });
    }
    return (
<>
        <nav>
          <ul>
          <li onClick={() => navigate("product/ListProduct", {replace : true})}>
              <Link >List Products</Link>
            </li>
            <li onClick={() => navigate("../product/create", {replace : true})}>
              <Link >Create Product</Link>
            </li>
            <li onClick={() => navigate("../user/create", {replace : true})}>
              <Link >Create User</Link>
            </li>
            <li onClick={() => navigate("../user/", {replace : true})}>
              <Link>List User</Link>
            </li> 
            <li onClick={() => navigate("../brand/create", {replace : true})}>
              <Link >Create Brand</Link>
            </li>
            <li onClick={() => navigate("../brand/", {replace : true})}>
              <Link>List Brand</Link>
            </li>  
            <li onClick={() => navigate("../category/create", {replace : true})}>
              <Link >Create Category</Link>
            </li>
            <li onClick={() => navigate("../category/", {replace : true})}>
              <Link>List Category</Link>
            </li>    
            <li onClick={() => navigate("../order/create", {replace : true})}>
              <Link >Create Order</Link>
            </li>
            <li onClick={() => navigate("../order/", {replace : true})}>
              <Link>List Order</Link>
            </li> 
            <li onClick={() => navigate("../brandInfo/", {replace : true})}>
              <Link>BrandInfo</Link>
            </li>                    
          </ul>
        </nav>
        <div>
            <h1>List Order</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Pid</th>
                        <th>Quantity</th>
                        <th>Invoiceno</th>
                        <th>Cusname</th>
                        <th>Cusphno</th>
                        <th>Paymentmode</th>
                        <th>Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {orders.map((order, key) =>
                        <tr key={key}>
                            <td>{order.id}</td>
                            <td>{order.pid}</td>
                            <td>{order.qty}</td>
                            <td>{order.invoiceno}</td>
                            <td>{order.cusname}</td>
                            <td>{order.cphno}</td>
                            <td>{order.paymentmode}</td>
                            <td>{order.amount}</td>
                            <td>
                                <Link to={`/order/${order.id}/edit`} style={{marginRight: "10px"}}>Edit</Link>
                                <button onClick={() => deleteOrder(order.id)}>Delete</button>
                            </td>
                        </tr>
                    )}
                    
                </tbody>
            </table>
        </div>
        </>
    )
}
