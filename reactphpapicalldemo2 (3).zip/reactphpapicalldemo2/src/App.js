import {BrowserRouter, Routes, Route, Link} from 'react-router-dom';
import './App.css';

import Login from './components/Login';
import Register from './components/Register';
import CreateProduct from './components/CreateProduct';
import EditProduct from './components/EditProduct';
import ListProduct from './components/ListProduct';

import CreateUser from './components/CreateUser';
import EditUser from './components/EditUser';
import ListUser from './components/ListUser';

import CreateBrand from './components/CreateBrand';
import EditBrand from './components/EditBrand';
import ListBrand from './components/ListBrand';

import CreateCategory from './components/CreateCategory';
import EditCategory from './components/EditCategory';
import ListCategory from './components/ListCategory';

import CreateOrder from './components/CreateOrder';
import EditOrder from './components/EditOrder';
import ListOrder from './components/ListOrder';
import StudentInfo from './components/brandInfo';
import  {useEffect , useState  }from 'react';

function App(){
 const [auth, setAuth] = useState(false);

  const logout = () => {
    localStorage.setItem('token', null);
    setAuth(false)
  }
  return (
    <div className="App">
      <h1><b>Welcome to Dairy Daily</b></h1>
      <BrowserRouter>
        <Routes>
          {/* <Route index element={<Login />} /> */}
          <Route index element={<Login />} />
          {/* ... other Route elements ... */}
        <Route path="register" element={<Register />} />
          <Route path="ListProduct" element={<ListProduct />} />
          <Route path="product/create" element={<CreateProduct />} />
          <Route path="ListProduct/product/:id/edit" element={<EditProduct />} />
          {/* <Route index element={<ListUser />} /> */}
          <Route path="/user/" element={<ListUser />} />
          <Route path="user/:id/edit" element={<EditUser />} />
          <Route path="user/create" element={<CreateUser />} />

          <Route path="/brand/" element={<ListBrand />} />
          <Route path="brand/:id/edit" element={<EditBrand />} />
          <Route path="brand/create" element={<CreateBrand />} />

          <Route path="/category/" element={<ListCategory />} />
          <Route path="category/:id/edit" element={<EditCategory />} />
          <Route path="category/create" element={<CreateCategory />} />

          <Route path="/order/" element={<ListOrder />} />
          <Route path="order/:id/edit" element={<EditOrder />} />
          <Route path="order/create" element={<CreateOrder />} />
    
          <Route path="/brandInfo" element={<StudentInfo />} />
         
        </Routes>
      </BrowserRouter> 
    </div>
  );
}

export default App;
