import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBZ_fvPe9D-ITUjENoFm952jeoU1eRHTTo",
  authDomain: "tasklatest.firebaseapp.com",
  projectId: "tasklatest",
  storageBucket: "tasklatest.appspot.com",
  messagingSenderId: "1011202042163",
  appId: "1:1011202042163:web:99f667d0ccb230b17b7646"
};



const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };
